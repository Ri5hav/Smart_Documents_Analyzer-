from flask import Flask, request, render_template, jsonify
from utils.ocr import extract_text
from utils.nlp import extract_entities
import os

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = "uploads/"
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        file = request.files.get("file")
        if not file:
            return "No file uploaded", 400
        path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
        file.save(path)

        text = extract_text(path)
        entities = extract_entities(text)

        return render_template("index.html", text=text, entities=entities)
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
