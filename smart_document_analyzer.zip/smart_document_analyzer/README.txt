SMART DOCUMENT ANALYZER - SETUP GUIDE

1. Create a virtual environment and activate it:
   python3 -m venv venv
   source venv/bin/activate    # On Windows: venv\Scripts\activate

2. Install dependencies:
   pip install -r requirements.txt

3. Download the NLP model used (spaCy small English model):
   python -m spacy download en_core_web_sm

4. Run the application:
   python app.py

5. Open your browser and navigate to:
   http://127.0.0.1:5000/

Place your code in the respective files inside utils/, templates/, and app.py.
